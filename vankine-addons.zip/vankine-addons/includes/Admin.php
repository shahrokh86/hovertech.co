<?php
namespace Vankineaddons;
/**
 * The admin class
 */
class Admin{
    /**
     * Initialize the class
     */
    function __construct()
    {
        new Plugins\Header;
        new Plugins\Megamenu;
        new Plugins\Service;
        new Plugins\Portfolio;  
        new Plugins\Footer;
        new Core\Functions;
    }
}
