<?php
/*
** ===================
** Vankine Header
** Post type : Header;
** version: 1.0;
** Authour : Steeltheme;
** ===================
*/
namespace Vankineaddons\Plugins;
if (! defined('ABSPATH' )){
	die('-1');
}
class Header{
	public function __construct() {
		add_action('init', array($this, 'header_custom_post_type'));   
	}
	public function header_custom_post_type() {
		register_post_type( 'header',
		array(
			'labels' => array(
			'name' => esc_html_x('Headers', 'Post Type General Name', 'vankine-addons') ,
			'singular_name' => esc_html_x('Headers', 'Post Type General Name', 'vankine-addons') , 
			'add_new' =>  esc_html__('Add New', 'vankine-addons'),
			'add_new_item' =>   esc_html__('Add New Header', 'vankine-addons'),
			'edit' => esc_html__('Edit', 'vankine-addons'),
			'edit_item' =>   esc_html__('Edit Header', 'vankine-addons'),
			'new_item' =>   esc_html__('New Header', 'vankine-addons'),
			'view' =>  esc_html__('View', 'vankine-addons'),
			'view_item' =>    esc_html__('View Header', 'vankine-addons'),
			'search_items' =>   esc_html__('Search Header', 'vankine-addons'),
			'not_found' =>   esc_html__('No Header found', 'vankine-addons'),
			'not_found_in_trash' =>  esc_html__('No Header found in Trash', 'vankine-addons'),
			'parent' =>  esc_html__('Parent Header', 'vankine-addons')
			),
		
			'public' => true,
			'show_in_rest' => true, 
			'rewrite'               => array('slug' => 'header'),
			'supports' =>
			array( 'title' , 'editor', 'page-attributes' ),
			'taxonomies' => array( '' ),
			'show_in_menu'        => 'vankine',
			'show_in_nav_menus'   => false,
			'menu_position'       => 4,
			'menu_icon'           => 'dashicons-heading',
			'has_archive' => false,
			'capability_type'    => 'post',
			'hierarchical'          => true,
			)
		);
	}
}
?>