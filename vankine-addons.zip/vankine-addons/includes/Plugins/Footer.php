<?php
/*
** ===================
** Vankine Footer
** Post type : Footer;
** version: 1.0;
** Authour : Steeltheme;
** ===================
*/
namespace Vankineaddons\Plugins;
if (! defined('ABSPATH' )){
	die('-1');
}
class Footer{
   
	public function __construct() {
		add_action('init', array($this, 'footer_custom_post_type'));   
	}
	public function footer_custom_post_type() {
		register_post_type( 'footer',
		array(
			'labels' => array(
				'name' => esc_html_x('Footers', 'Post Type General Name', 'vankine-addons') ,
				'singular_name' => esc_html_x('Footers', 'Post Type General Name', 'vankine-addons') , 
				'add_new' =>  esc_html__('Add New', 'vankine-addons'),
				'add_new_item' =>   esc_html__('Add New Footer', 'vankine-addons'),
				'edit' => esc_html__('Edit', 'vankine-addons'),
				'edit_item' =>   esc_html__('Edit Footer', 'vankine-addons'),
				'new_item' =>   esc_html__('New Footer', 'vankine-addons'),
				'view' =>  esc_html__('View', 'vankine-addons'),
				'view_item' =>    esc_html__('View Footer', 'vankine-addons'),
				'search_items' =>   esc_html__('Search Footer', 'vankine-addons'),
				'not_found' =>   esc_html__('No Footer found', 'vankine-addons'),
				'not_found_in_trash' =>  esc_html__('No Footer found in Trash', 'vankine-addons'),
				'parent' =>  esc_html__('Parent Footer', 'vankine-addons')
			),
		
			'public' => true,
			'show_in_rest' => true,
			'supports' =>
			array( 'title', 'editor' , 'page-attributes' ),
			'taxonomies' => array( '' ),
			'show_in_menu'        => 'vankine',
			'show_in_nav_menus'   => false,
			'menu_position'       => 5,
			'menu_icon'           => 'dashicons-tagcloud',
			'has_archive' => false,
			'capability_type'    => 'post',
			'hierarchical'          => true,
		)
		 
		);
	}
 
}

?>