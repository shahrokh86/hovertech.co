<?php
/*
** ===================
** Vankine Mega Menu
** Post type : Mega Menu;
** version: 1.0;
** Authour : Steeltheme;
** ===================
*/
namespace Vankineaddons\Plugins;
if (! defined('ABSPATH' )){
	die('-1');
}
class Megamenu{
  	 
	public function __construct() {
		add_action('init', array($this, 'mega_menu_custom_post_type'));  
	}
	function mega_menu_custom_post_type() {
		register_post_type( 'mega_menu',
		array(
			'labels' => array(
			'name' => esc_html_x('Mega Menus ', 'Post Type General Name', 'vankine-addons') ,
			'singular_name' => esc_html_x('Mega Menu', 'Post Type General Name', 'vankine-addons') , 
			'add_new' =>  esc_html__('Add New', 'vankine-addons'),
			'add_new_item' =>   esc_html__('Add New Mega Menu', 'vankine-addons'),
			'edit' => esc_html__('Edit', 'vankine-addons'),
			'edit_item' =>   esc_html__('Edit Mega Menu', 'vankine-addons'),
			'new_item' =>   esc_html__('New Mega Menu', 'vankine-addons'),
			'view' =>  esc_html__('View', 'vankine-addons'),
			'view_item' =>    esc_html__('View Mega Menu', 'vankine-addons'),
			'search_items' =>   esc_html__('Search Mega Menu', 'vankine-addons'),
			'not_found' =>   esc_html__('No Mega Menu found', 'vankine-addons'),
			'not_found_in_trash' =>  esc_html__('No Mega Menu found in Trash', 'vankine-addons'),
			'parent' =>  esc_html__('Parent Mega Menu', 'vankine-addons')
		),
		'public' => true,
		'show_in_rest' => true,
		'supports' =>
		array( 'title' , 'editor' , 'page-attributes'),
		'taxonomies' => array( '' ),
		'show_in_menu'        => 'vankine',
		'show_in_nav_menus'   => true,
		'menu_position'       => 4,
		'menu_icon'           => 'dashicons-admin-generic',
		'has_archive' => false,
		'hierarchical'          => true,
		'capability_type'    => 'post',
		)
		);
	}
}

?>