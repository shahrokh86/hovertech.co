<?php

return array(
	'id'     => 'vankine_pageheader_settings',
	'title'  => esc_html__( "Page Header Settings", "vankine-addons" ),
	'fields' => array(
		array(
			'id'       => 'page_header_enable_disable',
			'type'     => 'switch',
			'title'    => esc_html__( 'Page Header Disable  / Enable', 'vankine-addons' ),
			'default'  => false,
			'desc' =>  esc_html__( 'Here  (Switch Off) is Enable and (Switch On) is Disable', 'vankine-addons' ),
		), 
		array(
			'id'       => 'page_header_title',
			'type'     => 'textarea',
			'title'    =>  esc_html__('Page Header Title', 'vankine-addons') ,
			'desc'     => esc_html__( 'Enter the title to show in Page Header section', 'vankine-addons' ),
			'required' => array( 'page_header_enable_disable', '=', false ),
		),
		array(
			'id'       => 'page_header_bg_image_showss',
			'type'     => 'switch',
			'title'    => esc_html__( 'Page Header Image Enable / Disable', 'vankine-addons' ),
			'default'  => false,
			'desc' =>  esc_html__( 'Here  (Switch Off) is Disable and (Switch On) is Enable', 'vankine-addons' ),
 
		),

		array(
			'id'       => 'page_header_bgimage',
			'type'     => 'media',
			'url'      => true,
			'title'    => esc_html__( 'Page Header Background Image', 'vankine-addons' ),
			'desc' =>  esc_html__( 'Enable to change background image for page header', 'vankine-addons' ),
			'required' => array( 'page_header_bg_image_showss', '=', true),
		),
	
		array(
			'id'       => 'page_header_bgcolor_enable',
			'type'     => 'switch',
			'title'    => esc_html__( 'Page Header Bakground Color Enable / Disable', 'vankine-addons' ),
			'default'  => false,
		 
			'desc' =>  esc_html__( 'Enable to change background color for page header', 'vankine-addons' ),
		),
		array(
			'id'       => 'page_header_bgcolor',
			'type'     => 'color',
			'title'    => esc_html__( 'Page Header Background Color', 'vankine-addons' ),
			'desc'     => esc_html__( 'Change Background Color for Page Header', 'vankine-addons' ),
			'required' => array( 'page_header_bgcolor_enable', '=', true ),
		),


		array(
			'id'       => 'page_header_title_enable',
			'type'     => 'switch',
			'title'    => esc_html__( 'Page Header Title Color Enable / Disable', 'vankine-addons' ),
			'default'  => false,
		 
			'desc' =>  esc_html__( 'Enable to change Title color for page header', 'vankine-addons' ),
		),
		array(
			'id'       => 'page_header_titlecolor',
			'type'     => 'color',
			'title'    => esc_html__( 'Page Header Title Color', 'vankine-addons' ),
			'desc'     => esc_html__( 'Change Title Color for Page Header', 'vankine-addons' ),
			'required' => array( 'page_header_title_enable', '=', true ),
		),


		array(
			'id'       => 'page_header_breadcrumb_enable',
			'type'     => 'switch',
			'title'    => esc_html__( 'Page Header Breadcrumb Color Enable / Disable', 'vankine-addons' ),
			'default'  => false,
		 
			'desc' =>  esc_html__( 'Enable to change Breadcrumb color for page header', 'vankine-addons' ),
		),
		array(
			'id'       => 'page_header_breadcolor',
			'type'     => 'color',
			'title'    => esc_html__( 'Page Header Breadcrumb Color', 'vankine-addons' ),
			'desc'     => esc_html__( 'Change Breadcrumb Color for Page Header', 'vankine-addons' ),
			'required' => array( 'page_header_breadcrumb_enable', '=', true ),
		),

		array(
			'id'       => 'page_header_breadarrcolor',
			'type'     => 'color',
			'title'    => esc_html__( 'Page Header Breadcrumb Arrow Color', 'vankine-addons' ),
			'desc'     => esc_html__( 'Change Breadcrumb Arrow Color for Page Header', 'vankine-addons' ),
			'required' => array( 'page_header_breadcrumb_enable', '=', true ),
		),

 
		array(
			'id'       => 'page_header_padding_custom',
			'type'     => 'text',
			'title'    => __('Page Header Padding', 'vankine-addons'),
			'placeholder'    => __('5rem 0px 5rem 0px', 'vankine-addons'),
			'default'  => '',
		 
		),
	 
	),
);