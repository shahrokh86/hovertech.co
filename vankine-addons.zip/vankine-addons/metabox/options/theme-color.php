<?php

return array(
	'id'     => 'vankine_themecolor_settings',
	'title'  => esc_html__( "Theme Color Settings", "vankine-addons" ),
	'fields' => array(
		
		array(
			'id'       => 'metapreloader_enable',
			'type'     => 'switch',
			'title'    => esc_html__( 'Preloader Color Enable', 'vankine-addons' ),
            'desc'    => esc_html__( 'Enable Preloader Color For This Page', 'vankine-addons' ),
			'default'  => false,
		),
		 
		array(         
			'id'       => 'metapre_loader_color_one',
			'type'     => 'color',
			'title'    => __('Preloader Color One', 'vankine-addons'),
			'validate' => 'color',
			'required' => [ 'metapreloader_enable', '=', true ],
		),

		array(         
			'id'       => 'metapre_loader_color_two',
			'type'     => 'color',
			'title'    => __('Preloader Color Two', 'vankine-addons'),
			'validate' => 'color',
			'required' => [ 'metapreloader_enable', '=', true ],
		),

		array(         
			'id'       => 'metapre_loader_color_three',
			'type'     => 'color',
			'title'    => __('Preloader Color Three', 'vankine-addons'),
			'validate' => 'color',
			'required' => [ 'metapreloader_enable', '=', true ],
		),

		array(
			'id'       => 'theme_color_enable',
			'type'     => 'switch',
			'title'    => esc_html__( 'Theme Color Enable', 'vankine-addons' ),
            'desc'    => esc_html__( 'Enable Theme Color For This Page', 'vankine-addons' ),
			'default'  => false,
		),
	 
	   
        array(
			'id'       => 'metatheme_colo_one',
			'type'     => 'color',
			'title'    => esc_html__( 'Theme Color - 1', 'vankine-addons' ),
			'required' => array( 'theme_color_enable', '=', true),
		),
		array(
			'id'       => 'metatheme_colo_two',
			'type'     => 'color',
			'title'    => esc_html__( 'Theme Color - 2', 'vankine-addons' ),
			'required' => array( 'theme_color_enable', '=', true),
		),
		array(
			'id'       => 'metatheme_colo_three',
			'type'     => 'color',
			'title'    => esc_html__( 'Theme Color - 3', 'vankine-addons' ),
			'required' => array( 'theme_color_enable', '=', true),
		),
		array(
			'id'       => 'metatheme_colo_four',
			'type'     => 'color',
			'title'    => esc_html__( 'Theme Color - 4', 'vankine-addons' ),
			'required' => array( 'theme_color_enable', '=', true),
		),
	 
		array(
			'id'       => 'metatheme_bgcolor_one',
			'type'     => 'color',
			'title'    => __('Theme Background Color (1)', 'vankine-addons'), 
			'validate' => 'color',
			'required' => array( 'theme_color_enable', '=', true ),
		),
		array(
			'id'       => 'metatheme_bgcolor_two',
			'type'     => 'color',
			'title'    => __('Theme Background Color (2)', 'vankine-addons'), 
			'description'    => __('Use Light Color', 'vankine-addons'), 
			'validate' => 'color',
			'required' => array( 'theme_color_enable', '=', true ),
		),
		array(
			'id'       => 'metatheme_bgcolor_three',
			'type'     => 'color',
			'title'    => __('Theme Background Color (3) ', 'vankine-addons'), 
			'description'    => __('Use Light Color', 'vankine-addons'), 
			'validate' => 'color',
			'required' => array( 'theme_color_enable', '=', true ),
		),
 
		array(
			'id'       => 'metaheading_color',
			'type'     => 'color',
			'title'    => __('Heading Color', 'vankine-addons'), 
			'validate' => 'color',
			'required' => array( 'theme_color_enable', '=', true ),
		),
	 
		array(
			'id'       => 'metadescription_color',
			'type'     => 'color',
			'title'    => __('Text  Color', 'vankine-addons'), 
			'validate' => 'color',
			'required' => array( 'theme_color_enable', '=', true ),
		),
  

		array(
			'id'       => 'metaborder_color',
			'type'     => 'color',
			'title'    => __('Border Color', 'vankine-addons'), 
			'validate' => 'color',
			'required' => array( 'theme_color_enable', '=', true ),
		),

		array(
			'id'       => 'metaborder_color_two',
			'type'     => 'color',
			'title'    => __('Border Color (2)', 'vankine-addons'), 
			'validate' => 'color',
			'required' => array( 'theme_color_enable', '=', true ),
		),

		array(
			'id'       => 'metaborder_color_three',
			'type'     => 'color',
			'title'    => __('Border Color (3)', 'vankine-addons'), 
			'validate' => 'color',
			'required' => array( 'theme_color_enable', '=', true ),
		),

		
		 
	),
);