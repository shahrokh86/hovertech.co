<?php
if ( ! function_exists( "vankine_add_metaboxes" ) ) {
	function vankine_add_metaboxes( $metaboxes ) {
		$directories_array = array(
			'page.php',
			'post.php',
			'service.php' ,
			'portfolio.php' ,
			'product.php'
		);
		foreach ( $directories_array as $dir ) {
			$metaboxes[] = require_once( VANKINE_ADDONS_DIR . '/metabox/' . $dir );
		}

		return $metaboxes;
	}

	add_action( "redux/metaboxes/vankine_theme_mod/boxes", "vankine_add_metaboxes" );
}

