<?php
return array(
	'title'      => __('Vankine Setting','vankine-addons' ),
	'id'         => 'vankine_page_meta',
	'icon'       => 'el el-cogs',
	'position'   => 'normal',
	'priority'   => 'core',
	'post_types' => array( 'page'),
	'sections'   => array(
		require VANKINE_ADDONS_DIR . '/metabox/options/general.php',
		require VANKINE_ADDONS_DIR . '/metabox/options/pageheader.php',
		require VANKINE_ADDONS_DIR . '/metabox/options/theme-color.php',
		
	),
);